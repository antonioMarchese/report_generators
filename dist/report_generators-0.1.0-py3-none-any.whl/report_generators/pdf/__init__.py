from .generator import BasePDFReportsGenerator

__all__ = ["BasePDFReportsGenerator"]
