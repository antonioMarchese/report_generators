from typing import List, Tuple


COLUMNS_TYPE = List[Tuple[str, int]]
