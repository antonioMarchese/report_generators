from .generator import BaseXLSXReportsGenerator

__all__ = ['BaseXLSXReportsGenerator']
